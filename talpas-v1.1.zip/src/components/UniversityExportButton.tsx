import { useState } from 'react';
import { WorkEntry, ClientConfig, InvoiceMetadata } from '../lib/types';
import { generateUniversityInvoice } from '../lib/docxGenerator';

interface Props {
  entries: WorkEntry[];
  client: ClientConfig;
  metadata: InvoiceMetadata;
  onExported?: () => void;
}

export default function UniversityExportButton({ entries, client, metadata, onExported }: Props) {
  const [loading, setLoading] = useState(false);

  const uncategorized = entries.filter(e => e.vrstaDela === null);
  const dpMissing = entries.filter(e => e.vrstaDela === 'Dp' && !e.dpZnesek);
  const missingMeta = !metadata.stevilkaRacuna || !metadata.datumRacuna || !metadata.rokPlacila;

  const errors: string[] = [];
  if (dpMissing.length > 0) errors.push(`${dpMissing.length} Dp vnosov brez zneska`);
  if (missingMeta) errors.push('Manjkajo podatki računa (številka, datum, rok plačila)');

  const handleExport = async () => {
    if (errors.length > 0) return;
    setLoading(true);
    try {
      await generateUniversityInvoice(entries, client, metadata);
      onExported?.();
    } catch (err) {
      alert('Napaka pri generiranju dokumenta: ' + String(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Izvoz – Univerza</h2>

      {errors.length > 0 ? (
        <div className="mb-4 space-y-1">
          {errors.map((e, i) => (
            <div key={i} className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded">
              <span>⛔</span> {e}
            </div>
          ))}
        </div>
      ) : (
        <div className="mb-4 space-y-1">
          <div className="text-sm text-green-600 bg-green-50 px-3 py-2 rounded flex items-center gap-2">
            <span>✅</span> Pripravljen za izvoz.
          </div>
          {uncategorized.length > 0 && (
            <div className="text-sm text-gray-500 bg-gray-50 px-3 py-2 rounded flex items-center gap-2">
              <span>ℹ</span> {uncategorized.length} neoznačenih vnosov se ne upošteva.
            </div>
          )}
        </div>
      )}

      <button
        onClick={handleExport}
        disabled={errors.length > 0 || loading}
        className={`px-6 py-3 rounded-lg font-semibold text-white transition-all ${
          errors.length > 0 || loading
            ? 'bg-gray-300 cursor-not-allowed'
            : 'bg-purple-600 hover:bg-purple-700 active:scale-95'
        }`}
      >
        {loading ? '⏳ Generiranje...' : '📄 Izvozi Word račun – Univerza (.docx)'}
      </button>
    </div>
  );
}
